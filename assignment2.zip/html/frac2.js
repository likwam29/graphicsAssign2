var frac2 = {
  "transformations": [
    {
      "prob": 0.787473,
      "trans_y": -0.110607,
      "trans_x": -1.88229,
      "rotate_scaleyy": 0.864198,
      "rotate_scaleyx": -0.212346,
      "rotate_scalexy": 0.281482,
      "rotate_scalexx": 0.824074
    },
    {
      "prob": 0.212527,
      "trans_y": 8.095795,
      "trans_x": 0.78536,
      "rotate_scaleyy": -0.377778,
      "rotate_scaleyx": -0.463889,
      "rotate_scalexy": 0.520988,
      "rotate_scalexx": 0.088272
    }
  ],
  "name": "dragon"
};