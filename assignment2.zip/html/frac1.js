var frac1 = {
  "transformations": [
    {
      "prob": 0.13,
      "trans_y": 0.02,
      "trans_x": 2.14,
      "rotate_scaleyy": 0.34,
      "rotate_scaleyx": 0.0,
      "rotate_scalexy": 0.0,
      "rotate_scalexx": 0.34
    },
    {
      "prob": 0.13,
      "trans_y": 1.11,
      "trans_x": 1.06,
      "rotate_scaleyy": 0.0,
      "rotate_scaleyx": -0.34,
      "rotate_scalexy": 0.34,
      "rotate_scalexx": 0.0
    },
    {
      "prob": 0.13,
      "trans_y": 2.18,
      "trans_x": 0.0,
      "rotate_scaleyy": 0.34,
      "rotate_scaleyx": 0.0,
      "rotate_scalexy": 0.0,
      "rotate_scalexx": 0.34
    },
    {
      "prob": 0.13,
      "trans_y": 1.11,
      "trans_x": -1.06,
      "rotate_scaleyy": 0.0,
      "rotate_scaleyx": 0.34,
      "rotate_scalexy": -0.34,
      "rotate_scalexx": 0.0
    },
    {
      "prob": 0.13,
      "trans_y": -1.08,
      "trans_x": -1.08,
      "rotate_scaleyy": 0.0,
      "rotate_scaleyx": 0.34,
      "rotate_scalexy": -0.34,
      "rotate_scalexx": 0.0
    },
    {
      "prob": 0.13,
      "trans_y": -2.18,
      "trans_x": 0.0,
      "rotate_scaleyy": -0.34,
      "rotate_scaleyx": 0.0,
      "rotate_scalexy": -0.0,
      "rotate_scalexx": -0.34
    },
    {
      "prob": 0.13,
      "trans_y": -1.09,
      "trans_x": 1.06,
      "rotate_scaleyy": 0.0,
      "rotate_scaleyx": -0.34,
      "rotate_scalexy": 0.34,
      "rotate_scalexx": 0.0
    },
    {
      "prob": 0.13,
      "trans_y": 0.01,
      "trans_x": -2.15,
      "rotate_scaleyy": 0.34,
      "rotate_scaleyx": 0.0,
      "rotate_scalexy": 0.0,
      "rotate_scalexx": 0.34
    }
  ],
  "name": "CARPET"
};